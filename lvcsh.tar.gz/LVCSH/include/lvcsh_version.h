! global version number
!
CHARACTER (LEN=6) :: version_number = '0.1.0'